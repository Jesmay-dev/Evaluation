package com.itn.jesmay;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.itn.jesmay.adapter.CourseAdapter;
import com.itn.jesmay.model.Course;
import com.itn.jesmay.network.RetrofitClient;
import com.itn.jesmay.model.EvaluationRequest;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity implements CourseAdapter.OnCourseClickListener {

    private RecyclerView recyclerView;
    private CourseAdapter adapter;
    private ProgressBar progressBar;
    private TextView tvError;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialisation des vues
        recyclerView = findViewById(R.id.recycler_courses);
        progressBar = findViewById(R.id.progress_bar);
        tvError = findViewById(R.id.tv_error);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Charger les cours depuis l'API
        loadCourses();
    }

    private void loadCourses() {
        showLoading(true);

        RetrofitClient.getInstance()
                .getApiService()
                .getCourses()
                .enqueue(new Callback<List<Course>>() {
                    @Override
                    public void onResponse(Call<List<Course>> call, Response<List<Course>> response) {
                        showLoading(false);
                        if (response.isSuccessful() && response.body() != null) {
                            List<Course> courses = response.body();
                            if (courses.isEmpty()) {
                                showError("Aucun cours disponible.");
                            } else {
                                showCourses(courses);
                            }
                        } else {
                            showError("Erreur serveur : " + response.code());
                        }
                    }

                    @Override
                    public void onFailure(Call<List<Course>> call, Throwable t) {
                        showLoading(false);
                        showError("Erreur réseau : " + t.getMessage());
                    }
                });
    }

    private void showCourses(List<Course> courses) {
        tvError.setVisibility(View.GONE);
        recyclerView.setVisibility(View.VISIBLE);

        if (adapter == null) {
            adapter = new CourseAdapter(courses, this);
            recyclerView.setAdapter(adapter);
        } else {
            adapter.updateList(courses);
        }
    }

    private void showLoading(boolean loading) {
        progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
        recyclerView.setVisibility(loading ? View.GONE : View.VISIBLE);
    }

    private void showError(String message) {
        recyclerView.setVisibility(View.GONE);
        tvError.setVisibility(View.VISIBLE);
        tvError.setText(message);
    }

    @Override
    public void onCourseClick(Course course) {
        // Naviguer vers l'écran d'évaluation avec les infos du cours
        Intent intent = new Intent(this, EvaluationActivity.class);
        intent.putExtra("course_id", course.getId());
        intent.putExtra("course_name", course.getName());
        startActivity(intent);
    }
}
