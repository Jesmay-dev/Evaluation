package com.itn.jesmay.network;

import com.itn.jesmay.model.ApiResponse;
import com.itn.jesmay.model.Course;
import com.itn.jesmay.model.EvaluationRequest;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface ApiService {

    // Récupérer la liste de tous les cours
    @GET("courses")
    Call<List<Course>> getCourses();

    // Soumettre une évaluation
    @POST("evaluations")
    Call<ApiResponse> submitEvaluation(@Body EvaluationRequest evaluation);
}
