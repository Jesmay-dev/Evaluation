package com.itn.jesmay.model;

import com.google.gson.annotations.SerializedName;

public class EvaluationRequest {

    @SerializedName("course_id")
    private int courseId;

    @SerializedName("date")
    private String date;

    @SerializedName("clarte_enseignant")
    private int clarteEnseignant;

    @SerializedName("qualite_contenu")
    private int qualiteContenu;

    @SerializedName("respect_programme")
    private int respectProgramme;

    @SerializedName("disponibilite_ressources")
    private int disponibiliteRessources;

    @SerializedName("interaction_etudiants")
    private int interactionEtudiants;

    public EvaluationRequest(int courseId, String date, int clarteEnseignant,
                             int qualiteContenu, int respectProgramme,
                             int disponibiliteRessources, int interactionEtudiants) {
        this.courseId = courseId;
        this.date = date;
        this.clarteEnseignant = clarteEnseignant;
        this.qualiteContenu = qualiteContenu;
        this.respectProgramme = respectProgramme;
        this.disponibiliteRessources = disponibiliteRessources;
        this.interactionEtudiants = interactionEtudiants;
    }

    public int getCourseId() { return courseId; }
    public void setCourseId(int courseId) { this.courseId = courseId; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public int getClarteEnseignant() { return clarteEnseignant; }
    public void setClarteEnseignant(int clarteEnseignant) { this.clarteEnseignant = clarteEnseignant; }

    public int getQualiteContenu() { return qualiteContenu; }
    public void setQualiteContenu(int qualiteContenu) { this.qualiteContenu = qualiteContenu; }

    public int getRespectProgramme() { return respectProgramme; }
    public void setRespectProgramme(int respectProgramme) { this.respectProgramme = respectProgramme; }

    public int getDisponibiliteRessources() { return disponibiliteRessources; }
    public void setDisponibiliteRessources(int disponibiliteRessources) { this.disponibiliteRessources = disponibiliteRessources; }

    public int getInteractionEtudiants() { return interactionEtudiants; }
    public void setInteractionEtudiants(int interactionEtudiants) { this.interactionEtudiants = interactionEtudiants; }
}
