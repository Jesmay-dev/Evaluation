package com.itn.jesmay;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ProgressBar;

import androidx.appcompat.app.AppCompatActivity;

import com.itn.jesmay.model.ApiResponse;
import com.itn.jesmay.model.EvaluationRequest;
import com.itn.jesmay.network.RetrofitClient;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EvaluationActivity extends AppCompatActivity {

    private TextView tvCourseTitle;
    private TextView tvSelectedDate;
    private RatingBar ratingClarte;
    private RatingBar ratingQualite;
    private RatingBar ratingRespect;
    private RatingBar ratingDisponibilite;
    private RatingBar ratingInteraction;
    private Button btnSelectDate;
    private Button btnSoumettre;
    private ProgressBar progressBar;

    private int courseId;
    private String courseName;
    private String selectedDate = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_evaluation);

        // Récupérer les données du cours
        courseId = getIntent().getIntExtra("course_id", -1);
        courseName = getIntent().getStringExtra("course_name");

        // Initialiser les vues
        initViews();

        // Afficher le nom du cours
        tvCourseTitle.setText("Évaluer : " + courseName);

        // Date par défaut = aujourd'hui
        setTodayDate();

        // Bouton sélection date
        btnSelectDate.setOnClickListener(v -> showDatePicker());

        // Bouton soumettre
        btnSoumettre.setOnClickListener(v -> submitEvaluation());
    }

    private void initViews() {
        tvCourseTitle       = findViewById(R.id.tv_course_title);
        tvSelectedDate      = findViewById(R.id.tv_selected_date);
        ratingClarte        = findViewById(R.id.rating_clarte);
        ratingQualite       = findViewById(R.id.rating_qualite);
        ratingRespect       = findViewById(R.id.rating_respect);
        ratingDisponibilite = findViewById(R.id.rating_disponibilite);
        ratingInteraction   = findViewById(R.id.rating_interaction);
        btnSelectDate       = findViewById(R.id.btn_select_date);
        btnSoumettre        = findViewById(R.id.btn_soumettre);
        progressBar         = findViewById(R.id.progress_bar);
    }

    private void setTodayDate() {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        selectedDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(calendar.getTime());
        tvSelectedDate.setText(sdf.format(calendar.getTime()));
    }

    private void showDatePicker() {
        Calendar calendar = Calendar.getInstance();
        DatePickerDialog dialog = new DatePickerDialog(
                this,
                (view, year, month, dayOfMonth) -> {
                    // Format pour l'affichage
                    String display = String.format(Locale.getDefault(), "%02d/%02d/%04d", dayOfMonth, month + 1, year);
                    tvSelectedDate.setText(display);
                    // Format pour l'API
                    selectedDate = String.format(Locale.getDefault(), "%04d-%02d-%02d", year, month + 1, dayOfMonth);
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        );
        dialog.show();
    }

    private void submitEvaluation() {
        // Validation
        if (selectedDate.isEmpty()) {
            Toast.makeText(this, "Veuillez sélectionner une date.", Toast.LENGTH_SHORT).show();
            return;
        }

        int clarte        = (int) ratingClarte.getRating();
        int qualite       = (int) ratingQualite.getRating();
        int respect       = (int) ratingRespect.getRating();
        int disponibilite = (int) ratingDisponibilite.getRating();
        int interaction   = (int) ratingInteraction.getRating();

        if (clarte == 0 || qualite == 0 || respect == 0 || disponibilite == 0 || interaction == 0) {
            Toast.makeText(this, "Veuillez noter tous les critères.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Construire la requête
        EvaluationRequest request = new EvaluationRequest(
                courseId, selectedDate, clarte, qualite, respect, disponibilite, interaction
        );

        // Envoyer à l'API
        setLoading(true);
        RetrofitClient.getInstance()
                .getApiService()
                .submitEvaluation(request)
                .enqueue(new Callback<ApiResponse>() {
                    @Override
                    public void onResponse(Call<ApiResponse> call, Response<ApiResponse> response) {
                        setLoading(false);
                        if (response.isSuccessful() && response.body() != null) {
                            ApiResponse apiResponse = response.body();
                            if (apiResponse.isSuccess()) {
                                Toast.makeText(EvaluationActivity.this,
                                        "Évaluation soumise avec succès !", Toast.LENGTH_LONG).show();
                                finish(); // Retour à la liste
                            } else {
                                Toast.makeText(EvaluationActivity.this,
                                        "Erreur : " + apiResponse.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(EvaluationActivity.this,
                                    "Erreur serveur : " + response.code(), Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<ApiResponse> call, Throwable t) {
                        setLoading(false);
                        Toast.makeText(EvaluationActivity.this,
                                "Erreur réseau : " + t.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void setLoading(boolean loading) {
        progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
        btnSoumettre.setEnabled(!loading);
    }
}
